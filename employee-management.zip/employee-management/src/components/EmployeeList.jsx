import Header from "./Header";
import { useNavigate } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    fetchUsers,
    setSearch,
    setCurrentPage,
    setPerPage,
} from '../slice/UserSlice';

import {
    Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper,
    TextField, Select, MenuItem, TablePagination, IconButton
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import VisibilityIcon from '@mui/icons-material/Visibility'; // Import the View icon
import { Box, Button } from '@mui/material'; // Import Box and Button from Material-UI
import { confirmAlert } from "react-confirm-alert";
import "react-confirm-alert/src/react-confirm-alert.css";
import { deleteUser,bulkDeleteUsers } from '../actions/userActions';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const EmployeeList = () => {

    const navigate = useNavigate();
    const dispatch = useDispatch();
    const { data, loading, meta, search } = useSelector((state) => state.users);
    const [selectedUsers, setSelectedUsers] = useState([]); // State to track selected users

    // Handle "Select All" checkbox toggle
    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allUserIds = data.map((user) => user.id);
            setSelectedUsers(allUserIds);
        } else {
            setSelectedUsers([]);
        }
    };

    // Handle individual checkbox toggle
    const handleCheckboxChange = (id) => {
        setSelectedUsers((prevSelected) =>
            prevSelected.includes(id)
                ? prevSelected.filter((userId) => userId !== id)
                : [...prevSelected, id]
        );
    };

    useEffect(() => {
        dispatch(fetchUsers({ page: meta.currentPage, perPage: meta.perPage, search }));
    }, [dispatch, meta.currentPage, meta.perPage, search]);

    const handleChangePage = (_, newPage) => {
        dispatch(setCurrentPage(newPage + 1));
    };

    const handleChangeRowsPerPage = (event) => {
        dispatch(setPerPage(parseInt(event.target.value, 10)));
    };

    const handleSearchChange = (e) => {
        dispatch(setSearch(e.target.value));
    };

    const handleClick = () => {
        navigate('/add');  // replace with your desired route
    };


    const handleDelete = (id) => {
        confirmAlert({
            title: "Confirm to Delete",
            message: "Are you sure you want to delete this user?",
            buttons: [
                {
                    label: "Yes",
                    onClick: () => {
                        dispatch(deleteUser(id))
                            .unwrap()
                            .then(() => {
                                toast.success("User deleted successfully!");
                            })
                            .catch((error) => {
                                console.error("Error deleting user:", error);
                                toast.error("Failed to delete user. Please try again.");
                            });
                    },
                },
                {
                    label: "No",
                },
            ],
        });
    };

    // Handle bulk delete
    const handleBulkDelete = () => {
        console.log("Bulk delete for user IDs:", selectedUsers);
        if (selectedUsers.length === 0) {
            toast.error("No users selected for deletion.");
            return;
        }
        confirmAlert({
            title: "Confirm to Delete",
            message: "Are you sure you want to delete the selected users?",
            buttons: [
                {
                    label: "Yes",
                    onClick: () => {
                        dispatch(bulkDeleteUsers(selectedUsers))
                            .unwrap()
                            .then(() => {
                                toast.success("Selected users deleted successfully!");
                                setSelectedUsers([]); // Clear the selection
                            })
                            .catch((error) => {
                                console.error("Error deleting users:", error);
                                toast.error("Failed to delete some users. Please try again.");
                            });
                    },
                },
                {
                    label: "No",
                },
            ],
        });
    };


    return (
        <>
            {/* <Header></Header>
            <table className='table table-striped table-hover'>
                <thead>
                    <tr>
                        <th>
                            <span className='custom-checkbox'>
                                <input type='checkbox' id='selectAll' />
                                <label htmlFor='selectAll'></label>
                            </span>
                        </th>
                        <th>Sr.no</th>
                        <th>Full name</th>
                        <th>Mobile</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <span className='custom-checkbox'>
                                <input type='checkbox' id='checkbox1' />
                                <label htmlFor='checkbox1'></label>
                            </span>
                        </td>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>1234567890</td>
                        <td>09/07/1990</td>
                        <td>Female</td>
                        <td>
                            <a href='#editEmployeeModal' className='edit' style={{ color: "green" }}>
                                <TbEdit onClick={() => handleEditModal(user.id)} />
                            </a>
                            <a href='#'
                                className='delete'>
                                <MdDelete onClick={() => { handleDelete(user.id) }} />
                            </a>
                            <a href='#'
                                className='view'>
                                <GrView />
                            </a>
                            
                        </td>
                    </tr>

                </tbody>
            </table> */}
            <Paper sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                    <TextField
                        label="Search"
                        variant="outlined"
                        value={search}
                        onChange={handleSearchChange}
                        sx={{ flex: 1, mr: 2 }} // Make the search field flexible and add margin
                    />
                    <Button
                        variant="contained"
                        color="primary"  onClick={handleClick} sx={{ mr: 2 }} >
                        Add User 
                    </Button>
                    <Button
                        variant="contained"
                        color="error" onClick={handleBulkDelete} disabled={selectedUsers.length === 0}>
                        Delete
                    </Button>


                </Box>
                <TableContainer component={Paper}>
                    <Table>
                        <TableHead sx={{ backgroundColor: '#f5f5f5' }}>
                            <TableRow>
                                <TableCell>
                                    <input
                                        type="checkbox"
                                        onChange={handleSelectAll}
                                        checked={selectedUsers.length === data.length && data.length > 0}
                                    />
                                </TableCell>
                                <TableCell>Sr.No</TableCell>
                                <TableCell>Name</TableCell>
                                <TableCell>Mobile</TableCell>
                                <TableCell>DOB</TableCell>
                                <TableCell>Gender</TableCell>
                                {/* <TableCell>Address</TableCell> */}
                                <TableCell>Actions</TableCell>
                            </TableRow>
                        </TableHead>

                        <TableBody>
                            {loading ? (
                                <TableRow>
                                    <TableCell colSpan={4}>Loading...</TableCell>
                                </TableRow>
                            ) : data.length === 0 ? (
                                <TableRow>
                                    <TableCell colSpan={4}>No users found</TableCell>
                                </TableRow>
                            ) : (
                                data.map((user) => (
                                    <TableRow key={user.id}>
                                        <TableCell>  <input
                                            type="checkbox"
                                            checked={selectedUsers.includes(user.id)}
                                            onChange={() => handleCheckboxChange(user.id)}
                                        /></TableCell>
                                        <TableCell>{user.id}</TableCell>
                                        <TableCell>{user.full_name}</TableCell>
                                        <TableCell>{user.mobile}</TableCell>
                                        <TableCell>{user.dob}</TableCell>
                                        <TableCell>{user.gender}</TableCell>
                                        {/* <TableCell>{user.address?.city || '-'}</TableCell> */}
                                        <TableCell>
                                            <IconButton color="primary" onClick={() => navigate(`/edit/${user.id}`)}>
                                                <EditIcon />
                                            </IconButton>
                                            <IconButton color="error" onClick={() => handleDelete(user.id)}>
                                                <DeleteIcon />
                                            </IconButton>
                                            <IconButton color="info" onClick={() => navigate(`/view/${user.id}`)}>
                                                {/* <GrView /> */}
                                                {/* <VisibilityIcon /> */}
                                                {/* <VisibilityIcon color="action" /> */}
                                                {/* <VisibilityIcon color="primary" /> */}
                                                {/* <VisibilityIcon color="secondary" /> */}
                                                {/* <VisibilityIcon color="error" /> */}
                                                {/* <VisibilityIcon color="success" /> */}
                                                {/* <VisibilityIcon color="warning" /> */}
                                                <VisibilityIcon /> {/* Add the View icon */}
                                            </IconButton>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    </Table>
                    <ToastContainer />
                </TableContainer>

                <TablePagination
                    component="div"
                    count={meta.total}
                    page={meta.currentPage - 1}
                    onPageChange={handleChangePage}
                    rowsPerPage={meta.perPage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    rowsPerPageOptions={[10, 25, 50, 100]}
                />
            </Paper>
        </>
    );
}
export default EmployeeList;