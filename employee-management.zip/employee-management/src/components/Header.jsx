import { Link } from 'react-router-dom';
const Header = () => {

    return (
        <>
            <div className='app-container'>
                <div className='content'>
                    <header>
                        <div className='table-title'>
                            <div className='row'>
                                <div className='col-sm-6'>
                                    <h2>
                                        Manage <b>Employees</b>
                                    </h2>
                                </div>
                                <div className='col-sm-6'>
                                    <button type='button' className='btn btn-success'>
                                        {/* <IoIosAddCircleOutline/> */}
                                        <span>Add</span>
                                    </button>

                                    <a
                                        href='#deleteEmployeeModal'
                                        className='btn btn-danger'
                                        data-toggle='modal'
                                    >
                                        <span>Delete</span>
                                        {/* <MdDelete  onClick={handleBulkDelete} /> */}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </header>
                </div>
            </div>
        </>
    );
};
export default Header;
