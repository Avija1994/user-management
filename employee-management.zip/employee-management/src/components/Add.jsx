import 'bootstrap/dist/css/bootstrap.min.css'
import '../style.css';
import * as yup from "yup";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useDispatch } from "react-redux";
import { addUser } from "../actions/userActions";
import { useState } from "react";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link } from 'react-router-dom';
// Define the validation schema using Yup
const schema = yup.object().shape({
    full_name: yup.string().required("Full name is required"),
    mobile: yup.string().required("Mobile is required"),
    gender: yup.string().required("Gender is required"),
    dob: yup.string().required("Date of birth is required"),
    home_door_street: yup.string().required("Street is required"),
    home_landmark: yup.string().required("Landmark is required"),
    home_city: yup.string().required("City is required"),
    home_state: yup.string().required("State is required"),
    home_country: yup.string().required("Country is required"),
    home_primary: yup.string().required("Primary field is required"),
    office_door_street: yup.string().required("Street is required"),
    office_landmark: yup.string().required("Landmark is required"),
    office_city: yup.string().required("City is required"),
    office_state: yup.string().required("State is required"),
    office_country: yup.string().required("Country is required"),
    office_primary: yup.string().required("Primary field is required"),

});
const Add = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { data, loading, meta, search } = useSelector((state) => state.users);
    console.log(data);
    console.log(meta);
    const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) });

    const onSubmit = (data) => {
        let home_address = {
            address_type: "home",
            door_street: data.home_door_street,
            landmark: data.home_landmark,
            city: data.home_city,
            state: data.home_state,
            country: data.home_country,
            primary: data.home_primary

        }
        let office_address = {
            address_type: "office",
            door_street: data.office_door_street,
            landmark: data.office_landmark,
            city: data.office_city,
            state: data.office_state,
            country: data.office_country,
            primary: data.office_primary

        }
        let addreess = [home_address, office_address];
        // Combine user data and address data
        let formData = {
            full_name: data.full_name,
            mobile: data.mobile,
            dob: data.dob,
            gender: data.gender,
            address: addreess
        }
        console.log("Address Data:", addreess);
        console.log("Form Data:", formData);

        // Dispatch the registerUser action
        dispatch(addUser(formData))
            .unwrap() // Unwrap the promise to handle success and error
            .then((response) => {
                console.log("User added successfully:", response);
                toast.success("User added successfully!", {
                    position: "top-right",
                    autoClose: 3000, // Close after 3 seconds
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                    progress: undefined,
                }); // Show success toast
                setTimeout(() => {
                    navigate("/"); // Redirect to the listing page after a delay
                }, 2000); // 2-second delay
            })
            .catch((error) => {
                console.error("Error adding user:", error);
                toast.error("Failed to add user. Please try again."); // Show error toast
            });
    };


    return (
        <>
            <div className="container mt-5">
                <h1 className="text-center mb-4">User Details Form</h1>
                <Link to="/" className="btn btn-secondary mb-3">Back</Link> {/* Add Back button */}
                <form id="userDetailsForm" onSubmit={handleSubmit(onSubmit)}>
                    <fieldset className="border p-4 mb-4">
                        <legend className="w-auto px-2">User Details</legend>
                        <div className="row mb-3">
                            <div className="col-md-4">
                                <label htmlFor="user_name" className="form-label">Full Name:</label>
                                <input type="text" id="user_name" name="full_name" className={errors.full_name ? "form-control error-input" : "form-control"} placeholder="Enter Full Name" {...register("full_name")} />
                                {errors.full_name && <p className='error-message'>{errors.full_name.message}</p>}
                            </div>
                            <div className="col-md-3">
                                <label htmlFor="mobile" className="form-label">Mobile:</label>
                                <input type="tel" id="mobile" name="mobile" className={errors.mobile ? "form-control error-input" : "form-control"} placeholder="Enter Mobile Number" {...register("mobile")} />
                                {errors.mobile && <p className='error-message'>{errors.mobile.message}</p>}
                            </div>
                            <div className="col-md-3">
                                <label htmlFor="dob" className="form-label">Date of Birth:</label>
                                <input type="date" id="dob" name="dob" className={errors.dob ? "form-control error-input" : "form-control"} {...register("dob")} />
                                {errors.dob && <p className='error-message'>{errors.dob.message}</p>}
                            </div>
                            <div className="col-md-2">
                                <label htmlFor="gender" className="form-label">Gender:</label>
                                <select id="gender" name="gender" className={errors.gender ? "form-select error-input" : "form-select"} {...register("gender")}>
                                    <option value="">Select</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>

                                </select>
                                {errors.gender && <p className='error-message'>{errors.gender.message}</p>}
                            </div>
                        </div>
                    </fieldset>


                    <fieldset className="border p-4 mb-4">
                        <legend className="w-auto px-2">Home Address</legend>
                        <div className="row mb-3">
                            <input type="hidden" name="address_type" value="home" />
                            <div className="col-md-6">
                                <label htmlFor="home_door_street" className="form-label">Door/Street:</label>
                                <input type="text" id="home_door_street" name="home_door_street" className={errors.home_door_street ? "form-control error-input" : "form-control"} placeholder="Enter Door/Street" {...register("home_door_street")} />
                                {errors.home_door_street && <p className='error-message'>{errors.home_door_street.message}</p>}
                            </div>
                            <div className="col-md-6">
                                <label htmlFor="home_landmark" className="form-label">Landmark:</label>
                                <input type="text" id="home_landmark" name="home_landmark" className={errors.home_landmark ? "form-control error-input" : "form-control"} placeholder="Enter Landmark" {...register("home_landmark")} />
                                {errors.home_landmark && <p className='error-message'>{errors.home_landmark.message}</p>}
                            </div>
                        </div>
                        <div className="row mb-3">
                            <div className="col-md-4">
                                <label htmlFor="home_city" className="form-label">City:</label>
                                <input type="text" id="home_city" name="home_city" className={errors.home_city ? "form-control error-input" : "form-control"} placeholder="Enter City" {...register("home_city")} />
                                {errors.home_city && <p className='error-message'>{errors.home_city.message}</p>}
                            </div>
                            <div className="col-md-4">
                                <label htmlFor="home_state" className="form-label">State:</label>
                                <input type="text" id="home_state" name="home_state" className={errors.home_state ? "form-control error-input" : "form-control"} placeholder="Enter State" {...register("home_state")} />
                                {errors.home_state && <p className='error-message'>{errors.home_state.message}</p>}
                            </div>
                            <div className="col-md-4">
                                <label htmlFor="home_country" className="form-label">Country:</label>
                                <input type="text" id="home_country" name="home_country" className={errors.home_country ? "form-control error-input" : "form-control"} placeholder="Enter Country" {...register("home_country")} />
                                {errors.home_country && <p className='error-message'>{errors.home_country.message}</p>}
                            </div>
                        </div>
                        <div className="row mb-3">

                            <div className="col-md-2">
                                <label htmlFor="home_primary" className="form-label">Is Primary:</label>
                                <select id="home_primary" name="home_primary" className={errors.home_primary ? "form-select error-input" : "form-select"} {...register("home_primary")}>
                                    <option value="">Select</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                {errors.home_primary && <p className='error-message'>{errors.home_primary.message}</p>}
                            </div>
                        </div>
                    </fieldset>


                    <fieldset className="border p-4 mb-4">
                        <legend className="w-auto px-2">Office Address</legend>
                        <div className="row mb-3">
                            <input type="hidden" name="address_type" value="office" />
                            <div className="col-md-6">
                                <label htmlFor="office_door_street" className="form-label">Door/Street:</label>
                                <input type="text" id="office_door_street" name="office_door_street" className={errors.office_door_street ? "form-control error-input" : "form-control"} placeholder="Enter Door/Street" {...register("office_door_street")} />
                                {errors.office_door_street && <p className='error-message'>{errors.office_door_street.message}</p>}
                            </div>
                            <div className="col-md-6">
                                <label htmlFor="office_landmark" className="form-label">Landmark:</label>
                                <input type="text" id="office_landmark" name="office_landmark" className={errors.office_landmark ? "form-control error-input" : "form-control"} placeholder="Enter Landmark"  {...register("office_landmark")} />
                                {errors.office_landmark && <p className='error-message'>{errors.office_landmark.message}</p>}
                            </div>
                        </div>
                        <div className="row mb-3">
                            <div className="col-md-4">
                                <label htmlFor="office_city" className="form-label">City:</label>
                                <input type="text" id="office_city" name="office_city" className={errors.office_city ? "form-control error-input" : "form-control"} placeholder="Enter City" {...register("office_city")} />
                                {errors.office_city && <p className='error-message'>{errors.office_city.message}</p>}
                            </div>
                            <div className="col-md-4">
                                <label htmlFor="office_state" className="form-label">State:</label>
                                <input type="text" id="office_state" name="office_state" className={errors.office_state ? "form-control error-input" : "form-control"} placeholder="Enter State" {...register("office_state")} />
                                {errors.office_state && <p className='error-message'>{errors.office_state.message}</p>}
                            </div>
                            <div className="col-md-4">
                                <label htmlFor="office_country" className="form-label">Country:</label>
                                <input type="text" id="office_country" name="office_country" className={errors.office_country ? "form-control error-input" : "form-control"} placeholder="Enter Country"  {...register("office_country")} />
                                {errors.office_country && <p className='error-message'>{errors.office_country.message}</p>}
                            </div>
                        </div>
                        <div className="row mb-3">

                            <div className="col-md-2">
                                <label htmlFor="office_primary" className="form-label">Is Primary:</label>
                                <select id="office_primary" name="office_primary" className={errors.office_primary ? "form-select error-input" : "form-select"} {...register("office_primary")}>
                                    <option value="">Select</option>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
                                {errors.office_primary && <p className='error-message'>{errors.office_primary.message}</p>}
                            </div>
                        </div>
                    </fieldset>

                    <button type="submit" className="btn btn-primary w-100">Submit</button>
                </form>
            </div>
            <ToastContainer />
        </>
    );
}
export default Add;