import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { showUser } from "../actions/userActions";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Show = () => {
    const { id } = useParams(); // Get the user ID from the URL
    const dispatch = useDispatch();
    const [user, setUser] = useState(null); // State to store user data

    useEffect(() => {
        // Fetch the user data by ID
        dispatch(showUser(id))
            .unwrap()
            .then((response) => {
                setUser(response.data); // Set the user data in state
            })
            .catch((error) => {
                console.error("Error fetching user data:", error);
                toast.error("Failed to fetch user data.");
            });
    }, [dispatch, id]);

    if (!user) {
        return <p>Loading...</p>; // Show a loading message while fetching data
    }

    return (
        <div className="container mt-5">
            <h1 className="text-center mb-4">User Details</h1>
            <Link to="/" className="btn btn-secondary mb-3">Back</Link> {/* Back button */}
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title">Full Name: {user.full_name}</h5>
                    <p className="card-text">Mobile: {user.mobile}</p>
                    <p className="card-text">Date of Birth: {user.dob}</p>
                    <p className="card-text">Gender: {user.gender}</p>
                    <h6>Home Address:</h6>
                    <p className="card-text">Street: {user.address[0]?.door_street}</p>
                    <p className="card-text">Landmark: {user.address[0]?.landmark}</p>
                    <p className="card-text">City: {user.address[0]?.city}</p>
                    <p className="card-text">State: {user.address[0]?.state}</p>
                    <p className="card-text">Country: {user.address[0]?.country}</p>
                    <p className="card-text">Primary: {user.address[0]?.primary}</p>
                    <h6>Office Address:</h6>
                    <p className="card-text">Street: {user.address[1]?.door_street}</p>
                    <p className="card-text">Landmark: {user.address[1]?.landmark}</p>
                    <p className="card-text">City: {user.address[1]?.city}</p>
                    <p className="card-text">State: {user.address[1]?.state}</p>
                    <p className="card-text">Country: {user.address[1]?.country}</p>
                    <p className="card-text">Primary: {user.address[1]?.primary}</p>
                </div>
            </div>
            <ToastContainer />
        </div>
    );
};

export default Show;