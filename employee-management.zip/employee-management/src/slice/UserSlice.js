import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { addUser,updateUser,deleteUser,bulkDeleteUsers } from '../actions/userActions';

export const fetchUsers = createAsyncThunk('users/fetch', async ({ page, perPage, search }) => {
  const res = await axios.get('http://127.0.0.1:8000/api/employees', {
    params: { page, per_page: perPage, search }
  });
  console.log(res.data);
  return res.data;
});

// export const addUser = createAsyncThunk('users/addUser', async (userData) => {
//     const response = await axios.post('http://127.0.0.1:8000/api/employees', userData);
//     return response.data;
//   });

const userSlice = createSlice({
  name: 'users',
  initialState: {
    data: [],
    loading: false,
    error: null,
    meta: { total: 0, perPage: 10, currentPage: 1 },
    search: '',
  },
  reducers: {
    setSearch(state, action) {
      state.search = action.payload;
      state.meta.currentPage = 1;
    },
    setPerPage(state, action) {
      state.meta.perPage = action.payload;
      state.meta.currentPage = 1;
    },
    setCurrentPage(state, action) {
      state.meta.currentPage = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state) => { state.loading = true; })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload.data;
        state.meta.total = action.payload.total;
        state.meta.currentPage = action.payload.current_page;
        state.meta.perPage = action.payload.per_page;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      .addCase(addUser.pending, (state) => { state.loading = true; })
      .addCase(addUser.fulfilled, (state, action) => {
        state.loading = false;
      })
      .addCase(addUser.rejected, (state, action) => {
        state.loading = false;
      })
      .addCase(updateUser.pending, (state) => {
        state.loading = true;
    })
    .addCase(updateUser.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.data.findIndex((user) => user.id === action.payload.id);
        if (index !== -1) {
            state.data[index] = action.payload; // Update the user in the state
        }
    })
    .addCase(updateUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
    })
    .addCase(deleteUser.fulfilled, (state, action) => {
      state.data = state.data.filter((user) => user.id !== action.payload); // Remove the user from the state
      state.meta.total -= 1; // Decrease the total count
      state.loading = false;
    })
  .addCase(deleteUser.rejected, (state, action) => {
      state.error = action.payload;
  })
  .addCase(bulkDeleteUsers.fulfilled, (state, action) => {
    console.log('Bulk delete action payload:', action.payload);
    state.data = state.data.filter((user) => !action.payload.includes(user.id)); // Remove the users from the state
    state.meta.total -= action.payload.length; // Decrease the total count
})
.addCase(bulkDeleteUsers.rejected, (state, action) => {
    state.error = action.payload;
});

  }
});

export const { setSearch, setCurrentPage, setPerPage } = userSlice.actions;
export default userSlice.reducer;
