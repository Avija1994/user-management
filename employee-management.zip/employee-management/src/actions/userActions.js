import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const addUser = createAsyncThunk(
    'user/submitUser',
    async (userData, thunkAPI) => {
      console.log('userData:', userData);
      try {

        const response = await axios.post('http://127.0.0.1:8000/api/employees', userData);
        console.log('Response:', response);
        return response;
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response);
      }
    }
  );

  
export const fetchUsers = createAsyncThunk('users/fetch', async ({ page, perPage, search }) => {
  const res = await axios.get('http://127.0.0.1:8000/api/employees', {
    params: { page, per_page: perPage, search }
  });

  return res.data;
});

export const showUser = createAsyncThunk('user/show', async (id) => {
  const res = await axios.get(`http://127.0.0.1:8000/api/employees/${id}`, {
    params: { id }
  });

  return res.data;
});

export const updateUser = createAsyncThunk(
  "user/updateUser",
  async (userData, thunkAPI) => {
      try {
        console.log('userData:', userData);
          const response = await axios.put(`http://127.0.0.1:8000/api/employees/${userData.id}`, userData);
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response);
      }
  }
);

export const deleteUser = createAsyncThunk(
  "user/deleteUser",
  async (id, thunkAPI) => {
      try {
          await axios.delete(`http://127.0.0.1:8000/api/employees/${id}`);
          return id; // Return the deleted user's ID
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  }
);


export const bulkDeleteUsers = createAsyncThunk(
  "user/bulkDeleteUsers",
  async (userIds, thunkAPI) => {
    console.log('userIds:', userIds);
    console.log('usernIds:', { ids: userIds });

      try {
        const res = await axios({
          method: "delete",
          url: "http://127.0.0.1:8000/api/bulk-delete",
          data: { ids: userIds }, // Use the `data` property to send the request body
        });
        return userIds; // Return the deleted user IDs
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  }
);