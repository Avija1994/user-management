import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slice/UserSlice';  // adjust path as needed

const store = configureStore({
  reducer: {
    users: userReducer,
    // add other slices here if you have them
  },
});

export default store;
