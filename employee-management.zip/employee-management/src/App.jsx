import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
// import './App.css'
// import 'bootstrap/dist/css/bootstrap.min.css'
import { Routes,Route } from 'react-router-dom'
import EmployeeList from './components/EmployeeList'
import AddEmployee from './components/Add'
import EditEmployee from './components/Edit'
import ShowUserData from './components/show'
function App() {
  const [count, setCount] = useState(0)

  return (
    <>
        <Routes>
            <Route path="/" element={<EmployeeList></EmployeeList>}></Route>
            <Route path="/add" element={<AddEmployee></AddEmployee>}></Route>
            <Route path="/edit/:id" element={<EditEmployee></EditEmployee>}></Route>
            <Route path="/view/:id" element={<ShowUserData></ShowUserData>}></Route>
        </Routes>
    </>
  )
}

export default App
