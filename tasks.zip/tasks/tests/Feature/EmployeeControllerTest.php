<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\Employee;
use App\Models\Address;
use Illuminate\Foundation\Testing\RefreshDatabase;

class EmployeeControllerTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Test index function to retrieve employees with pagination.
     */
    public function test_index_employees()
    {
        Employee::factory()->count(5)->create();

        $response = $this->getJson('/api/employees');

        $response->assertStatus(200)
                 ->assertJsonStructure([
                     'data'
                 ]);
    }

    /**
     * Test store function to create a new employee with addresses.
     */
    public function test_store_employee()
    {
        $data = [
            'full_name' => 'John Doe',
            'mobile' => '1234567890',
            'dob' => '1990-01-01',
            'gender' => 'Male',
            'address' => [
                [
                    'address_type' => 'home',
                    'door_street' => '123 Main St',
                    'landmark' => 'Near Park',
                    'city' => 'New York',
                    'state' => 'NY',
                    'country' => 'USA',
                    'primary' => 'Yes',
                ],
            ],
        ];

        $response = $this->postJson('/api/employees', $data);

        $response->assertStatus(201)
                 ->assertJsonFragment(['full_name' => 'John Doe']);

        $this->assertDatabaseHas('employees', ['full_name' => 'John Doe']);
        $this->assertDatabaseHas('employee_address', ['city' => 'New York']);
    }

    /**
     * Test show function to retrieve a single employee with addresses.
     */
    public function test_show_employee()
    {
        $employee = Employee::factory()->create();
        $address = Address::factory()->create(['employee_id' => $employee->id]);

        $response = $this->getJson("/api/employees/{$employee->id}");

        $response->assertStatus(200)
                 ->assertJsonFragment(['id' => $employee->id]);
    }

    /**
     * Test update function to update an employee and their addresses.
     */
    public function test_update_employee()
    {
        $employee = Employee::factory()->create();
        $address = Address::factory()->create(['employee_id' => $employee->id]);

        $data = [
            'full_name' => 'Jane Doe',
            'mobile' => '9876543210',
            'dob' => '1995-05-05',
            'gender' => 'Female',
            'address' => [
                [
                    'id' => $address->id,
                    'address_type' => 'office',
                    'door_street' => '456 Elm St',
                    'landmark' => 'Near Mall',
                    'city' => 'Los Angeles',
                    'state' => 'CA',
                    'country' => 'USA',
                    'primary' => 'No',
                ],
            ],
        ];

        $response = $this->putJson("/api/employees/{$employee->id}", $data);

        $response->assertStatus(200)
                 ->assertJsonFragment(['full_name' => 'Jane Doe']);

        $this->assertDatabaseHas('employees', ['full_name' => 'Jane Doe']);
        $this->assertDatabaseHas('employee_address', ['city' => 'Los Angeles']);
    }

    /**
     * Test destroy function to delete an employee.
     */
    public function test_destroy_employee()
    {
        $employee = Employee::factory()->create();

        $response = $this->deleteJson("/api/employees/{$employee->id}");

        $response->assertStatus(200)
                 ->assertJsonFragment(['message' => 'User deleted successfully']);

        $this->assertDatabaseMissing('employees', ['id' => $employee->id]);
    }

    /**
     * Test bulkDelete function to delete multiple employees.
     */
    public function test_bulk_delete_employees()
    {
        $employees = Employee::factory()->count(5)->create();
        $idsToDelete = $employees->pluck('id')->take(3)->toArray();

        $response = $this->deleteJson('/api/bulk-delete', [
            'ids' => $idsToDelete,
        ]);

        $response->assertStatus(200)
                 ->assertJsonFragment(['message' => 'Employees deleted successfully!']);

        foreach ($idsToDelete as $id) {
            $this->assertDatabaseMissing('employees', ['id' => $id]);
        }
    }
}
