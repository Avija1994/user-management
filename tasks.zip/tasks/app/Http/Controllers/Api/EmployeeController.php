<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\Address;
class EmployeeController extends Controller
{
    //

    public function index(Request $request){
        // Logic to retrieve and return a list of employees
        
        $query = Employee::with('address');

        if ($search = $request->search) {
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%$search%")
                ->orWhere('mobile', 'like', "%$search%")
                ->orWhereHas('address', fn($q) => 
                    $q->where('city', 'like', "%$search%")
                    ->orWhere('state', 'like', "%$search%")
                    ->orWhere('country', 'like', "%$search%")
                    ->orWhere('landmark', 'like', "%$search%")
                );
            });
        }

        return $query->paginate($request->per_page ?? 10);
    }

    public function store(Request $request){
        // echo "<pre>"; print_r($request->all()); die;
        $data = $request->all();
        // $data = $request->validate([
        //     'full_name' => 'required|string',
        //     'mobile' => 'required',
        //     'mobile' => 'required',
        //     'addresses.*.type' => 'required|in:home,office',
        //     'addresses.*.address_line' => 'required|string',
        //     'addresses.*.city' => 'required|string',
        //     'addresses.*.state' => 'required|string',
        //     'addresses.*.zip_code' => 'required|string',
        // ]);

        $user = Employee::create($request->only(['full_name', 'mobile','dob','gender']));
        foreach ($data['address'] as $address) {
            $user->address()->create($address);
        }

        return response()->json($user->load('address'), 201);
    }

    // Show single user with address
    public function show($id)
    {
        $user = Employee::with('address')->findOrFail($id);
        return response()->json(
            [
                'message' => 'User retrieved successfully',
                'data' => $user
        ]);
    }


    // Update employee and addresses
    public function update(Request $request, $id){
        // dd($id);
        $data = $request->all();
        $user = Employee::findOrFail($id);
        $user->update($request->only(['full_name', 'mobile','dob','gender']));

        if ($request->has('address')) {
            foreach ($data['address'] as $addressData) {
                $address = Address::findOrFail($addressData['id']);
                $address->update($addressData);
            }
        }

        return response()->json(
            [
                'status_code' => 200,
                'message' => 'User updated successfully',
                'data' => $user->load('address')
        ]);
    }

    public function destroy($id){
        
        $user = Employee::findOrFail($id);
        $user->delete();
        return response()->json(
            [
                'status_code' => 200,
                'message' => 'User deleted successfully',
        ]);
    }
    public function bulkDelete(Request $request){
       
        $validated = $request->validate([
            'ids' => 'required|array', // Ensure 'ids' is an array
            'ids.*' => 'exists:employees,id', // Ensure each ID exists in the employees table
        ]);
    
        // Perform bulk delete
        Employee::whereIn('id', $validated['ids'])->delete();
    
        return response()->json([
            'message' => 'Employees deleted successfully!',
            'deleted_ids' => $validated['ids'],
        ], 200);
    }
}
