<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Address extends Model
{
    use HasFactory;
    protected $table = 'employee_address'; // Specify the table name

    protected $fillable = [
        'employee_id',
        'address_type',
        'door_street',
        'landmark',
        'city',
        'state',
        'country',
        'primary',
    ]; // Define the fillable fields


    public function employee()
    {
        return $this->belongsTo(Employee::class);
    } // Define the relationship with the Employee model
}
