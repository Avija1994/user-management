<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Employee extends Model
{
    use HasFactory;
     protected $table = 'employees'; // Specify the table name

    protected $fillable = [
        'full_name',
        'mobile',
        'date',
        'dob',
        'gender',
    ]; 


    public function address()
    {
        return $this->hasMany(Address::class, 'employee_id');
    }
}
