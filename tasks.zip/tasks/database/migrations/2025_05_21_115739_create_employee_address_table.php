<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('employee_address', function (Blueprint $table) {
            $table->id(); // INT AUTO_INCREMENT PRIMARY KEY
            $table->unsignedBigInteger('employee_id'); // INT NOT NULL
            $table->enum('address_type', ['home', 'office'])->nullable(false); // ENUM('home', 'office') NOT NULL
            $table->string('door_street', 255)->nullable(false); // VARCHAR(255) NOT NULL
            $table->string('landmark', 255)->nullable(); // VARCHAR(255)
            $table->string('city', 100)->nullable(false); // VARCHAR(100) NOT NULL
            $table->string('state', 100)->nullable(false); // VARCHAR(100) NOT NULL
            $table->string('country', 100)->nullable(false); // VARCHAR(100) NOT NULL
            $table->enum('primary', ['Yes', 'No'])->nullable(false); // ENUM('Yes', 'No') NOT NULL

            $table->foreign('employee_id') // FOREIGN KEY (user_id) REFERENCES Employee(id)
                  ->references('id')
                  ->on('employees')
                  ->onDelete('cascade'); // Cascade delete if user is deleted

            $table->timestamps(); // Add created_at and updated_at columns
            $table->softDeletes(); // Add softDeletes column
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('employee_address');
    }
};
