<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Api\EmployeeController;
Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


// User management routes


// Route::get('/employees', [EmployeeController::class, 'index'])->name('employees.index');
Route::apiResource('employees', EmployeeController::class);
Route::delete('/bulk-delete', [EmployeeController::class, 'bulkDelete']);


