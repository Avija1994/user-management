<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
Route::get('/', function () {
    return view('welcome');
});


Route::get('test-cahe/', function () {
    Cache::put('greeting','Hii world', 60); // 60 seconds
    return Cache::get('greeting');
});

// Route::middleware('throttle:4,1')->get('/', function () {
//     return view('welcome');
// });